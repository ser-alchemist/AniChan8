create table Anime
(
	anime_id int primary key identity(1,1),
	title varchar(100),
	genre varchar(50),
	description_ varchar(200),
	rating float,
	episodes int,
	thumbnail varchar(150),
	trailer varchar(150),
	warning bit,
	premium bit,
	movie bit,
	poster varchar(200),
	slide varchar(200),
	upload_date date default GETDATE()
)

select * from Anime
/*
230.325c
1256.718p
1172.564s
*/
insert into Anime(title,genre,description_,rating,episodes,thumbnail,trailer,warning,premium,movie,poster,slide,upload_date)
values(
		'Your lie in April',
		'Drama, Music',
		'Kousei Arima is a child prodigy known as the "Human Metronome" for playing the piano with precision and perfection.[more]',
		8.6,
		22,
		'../../img/thumnails/yourlieinapril_cardview.jpg',
		'../../videos/',
		0,0,0,
		'../../img/poster/yourlieinapril_poster.jpg',
		'../../img/hero/yourlieinapril_slide.jpg',
		'2014-10-18'
		),
		( 'Dragon Ball Super',
		'Action, Shounen',
		'Seven years after the events of Dragon Ball Z, Earth is at peace',
		9.42,
		25,
		'../../img/thumnails/dbzsuper_cardview.jpg',
		'../../videos/',
		0,0,0,
		'../../img/poster/dbzsuper_poster.jpg',
		'../../img/hero/dbzsuper_slide.jpg',
		'2015-10-18' ),
		(
		 'My Hero Academia',
		 'Action, Adventure',
		 'The appearance of "quirks," newly discovered super powers, has been steadily increasing over the years, ',
		 9.15,
		 25,
		 '../../img/thumnails/myheroacademia_cardview.jpg',
		'../../videos/',
		0,0,0,
		'../../img/poster/myheroacademia_poster.jpg',
		'../../img/hero/myheroacademia_slide.jpg',
		'2014-10-18'
		),
		( 
		'HAIKYU',
		'Comedy, Sports',
		'Ever since having witnessed the "Little Giant" and his astonishing skills on the volleyball court,[more]',
		8.45,
		25,
		'../../img/thumnails/haikyuu_cardview.jpg',
		'../../videos/',
		0,0,0,
		'../../img/poster/haikyuu_poster.jpg',
		'../../img/hero/haikyuu_slide.jpg',
		'2014-06-18'
		),
		( 'Steins; Gate',
		'Drama, Sci-fi',
		'Eccentric scientist Rintarou Okabe has a never-ending thirst for scientific exploration.',
		9.08,
		25,
		'../../img/thumnails/haikyuu_cardview.jpg',
		'../../videos/',
		0,0,0,
		'../../img/poster/haikyuu_poster.jpg',
		'../../img/hero/haikyuu_slide.jpg',
		'2011-06-18'
		),
		(
		'Steins;Gate',
		'Sci-Fi, Thriller',
		'Together with his ditzy but well-meaning friend Mayuri Shiina and his roommate Itaru Hashida, Rintarou founds the Future Gadget Laboratory',
		9.08,
		25,
		'../../img/thumnails/steinsgate_cardview.jpg',
		'../../videos/',
		0,0,0,
		'../../img/poster/steinsgate_poster.jpg',
		'../../img/hero/steinsgate_slide.jpg',
		'2011-06-18'
		)
		
		
		
		
		
